import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.stream.Stream;
import java.time.format.DateTimeFormatter;

/**
 * Main application class for Campus Course & Records Manager (CCRM)
 * Entry point demonstrating proper Java application structure
 */
// (CCRMApplication class moved to its own file CCRMApplication.java)

// Singleton configuration class
class AppConfig {
    private static volatile AppConfig instance;
    
    private final Path dataFolderPath;
    private final Path backupFolderPath;
    private final int maxCreditsPerSemester;
    private final LocalDateTime startupTime;
    
    private AppConfig() {
        this.startupTime = LocalDateTime.now();
        this.dataFolderPath = Paths.get("data");
        this.backupFolderPath = Paths.get("backups");
        this.maxCreditsPerSemester = 24;
        
        initializeDirectories();
        System.out.println("AppConfig initialized at " + startupTime);
    }
    
    public static AppConfig getInstance() {
        if (instance == null) {
            synchronized (AppConfig.class) {
                if (instance == null) {
                    instance = new AppConfig();
                }
            }
        }
        return instance;
    }
    
    private void initializeDirectories() {
        try {
            if (!Files.exists(dataFolderPath)) {
                Files.createDirectories(dataFolderPath);
                System.out.println("Created data directory: " + dataFolderPath);
            }
            
            if (!Files.exists(backupFolderPath)) {
                Files.createDirectories(backupFolderPath);
                System.out.println("Created backup directory: " + backupFolderPath);
            }
        } catch (IOException e) {
            System.err.println("Error creating directories: " + e.getMessage());
        }
    }
    
    public Path getDataFolderPath() { return dataFolderPath; }
    public Path getBackupFolderPath() { return backupFolderPath; }
    public int getMaxCreditsPerSemester() { return maxCreditsPerSemester; }
    public LocalDateTime getStartupTime() { return startupTime; }
    
    public void displayPlatformInfo() {
        System.out.println("\n========== JAVA PLATFORM INFO ==========");
        System.out.println("Java SE: Standard Edition for core applications");
        System.out.println("Java EE: Enterprise Edition for server-side applications");
        System.out.println("Java ME: Micro Edition for embedded/mobile devices");
        System.out.println("Current Platform: Java SE");
        System.out.println("Java Version: " + System.getProperty("java.version"));
        System.out.println("==========================================\n");
    }
}

// Immutable Name class
final class Name {
    private final String firstName;
    private final String lastName;
    
    public Name(String firstName, String lastName) {
        this.firstName = firstName != null ? firstName.trim() : "";
        this.lastName = lastName != null ? lastName.trim() : "";
    }
    
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    
    public String getFullName() {
        return firstName + " " + lastName;
    }
    
    @Override
    public String toString() {
        return getFullName();
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Name name = (Name) obj;
        return Objects.equals(firstName, name.firstName) &&
               Objects.equals(lastName, name.lastName);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(firstName, lastName);
    }
}

// Grade enum
enum Grade {
    S(10.0, "S"), A(9.0, "A"), B(8.0, "B"), C(7.0, "C"), 
    D(6.0, "D"), E(5.0, "E"), F(0.0, "F");
    
    private final double gradePoints;
    private final String letterGrade;
    
    Grade(double gradePoints, String letterGrade) {
        this.gradePoints = gradePoints;
        this.letterGrade = letterGrade;
    }
    
    public double getGradePoints() { return gradePoints; }
    public String getLetterGrade() { return letterGrade; }
    
    @Override
    public String toString() {
        return letterGrade + " (" + gradePoints + ")";
    }
}

// Semester enum
enum Semester {
    SPRING("Spring", 1), SUMMER("Summer", 2), 
    FALL("Fall", 3), WINTER("Winter", 4);
    
    private final String displayName;
    private final int order;
    
    Semester(String displayName, int order) {
        this.displayName = displayName;
        this.order = order;
    }
    
    public String getDisplayName() { return displayName; }
    public int getOrder() { return order; }
    
    @Override
    public String toString() {
        return displayName;
    }
}

// Abstract Person class
abstract class Person {
    protected final String id;
    protected Name name;
    protected String email;
    protected LocalDate dateOfBirth;
    protected LocalDate createdDate;
    
    protected Person(String id, Name name, String email, LocalDate dateOfBirth) {
        this.id = Objects.requireNonNull(id, "ID cannot be null");
        this.name = Objects.requireNonNull(name, "Name cannot be null");
        this.email = Objects.requireNonNull(email, "Email cannot be null");
        this.dateOfBirth = dateOfBirth;
        this.createdDate = LocalDate.now();
    }
    
    public abstract String getPersonType();
    public abstract void displayProfile();
    
    public String getId() { return id; }
    public Name getName() { return name; }
    public String getEmail() { return email; }
    public LocalDate getDateOfBirth() { return dateOfBirth; }
    
    public int getAge() {
        if (dateOfBirth == null) return 0;
        return LocalDate.now().getYear() - dateOfBirth.getYear();
    }
    
    @Override
    public String toString() {
        return getPersonType() + "{id='" + id + "', name=" + name + "}";
    }
}

// Student class extending Person
class Student extends Person {
    public enum StudentStatus { ACTIVE, INACTIVE, GRADUATED, SUSPENDED }
    
    private String regNo;
    private StudentStatus status;
    private Set<String> enrolledCourses;
    private LocalDate enrollmentDate;
    private Map<String, Grade> courseGrades;
    
    public Student(String id, String regNo, Name name, String email, LocalDate dateOfBirth) {
        super(id, name, email, dateOfBirth);
        this.regNo = Objects.requireNonNull(regNo, "Registration number cannot be null");
        this.status = StudentStatus.ACTIVE;
        this.enrolledCourses = new HashSet<>();
        this.enrollmentDate = LocalDate.now();
        this.courseGrades = new HashMap<>();
    }
    
    @Override
    public String getPersonType() { return "Student"; }
    
    @Override
    public void displayProfile() {
        System.out.println("========== STUDENT PROFILE ==========");
        System.out.println("ID: " + getId());
        System.out.println("Registration No: " + regNo);
        System.out.println("Name: " + getName().getFullName());
        System.out.println("Email: " + getEmail());
        System.out.println("Age: " + getAge() + " years");
        System.out.println("Status: " + status);
        System.out.println("Enrollment Date: " + enrollmentDate);
        System.out.println("Enrolled Courses: " + enrolledCourses.size());
        System.out.println("Current GPA: " + String.format("%.2f", calculateGPA()));
        System.out.println("=====================================");
    }
    
    // Getters and setters
    public String getRegNo() { return regNo; }
    public StudentStatus getStatus() { return status; }
    public void setStatus(StudentStatus status) { this.status = status; }
    public LocalDate getEnrollmentDate() { return enrollmentDate; }
    public Set<String> getEnrolledCourses() { return new HashSet<>(enrolledCourses); }
    
    // Course management
    public boolean enrollInCourse(String courseCode) {
        return enrolledCourses.add(courseCode.toUpperCase());
    }
    
    public boolean unenrollFromCourse(String courseCode) {
        boolean removed = enrolledCourses.remove(courseCode.toUpperCase());
        if (removed) {
            courseGrades.remove(courseCode.toUpperCase());
        }
        return removed;
    }
    
    public boolean isEnrolledIn(String courseCode) {
        return enrolledCourses.contains(courseCode.toUpperCase());
    }
    
    // Grade management
    public void recordGrade(String courseCode, Grade grade) {
        if (isEnrolledIn(courseCode)) {
            courseGrades.put(courseCode.toUpperCase(), grade);
        }
    }
    
    public Grade getGrade(String courseCode) {
        return courseGrades.get(courseCode.toUpperCase());
    }
    
    public Map<String, Grade> getAllGrades() {
        return new HashMap<>(courseGrades);
    }
    
    // GPA calculation
    public double calculateGPA() {
        if (courseGrades.isEmpty()) return 0.0;
        return courseGrades.values().stream()
                .mapToDouble(Grade::getGradePoints)
                .average()
                .orElse(0.0);
    }
    
    public int getTotalCredits() {
        return enrolledCourses.size() * 3; // Assuming 3 credits per course
    }
    
    public boolean canEnrollInMoreCourses() {
        return getTotalCredits() < 24;
    }
    
    public String generateTranscript() {
        StringBuilder transcript = new StringBuilder();
        transcript.append("OFFICIAL TRANSCRIPT\n");
        transcript.append("==================\n");
        transcript.append("Student: ").append(getName().getFullName()).append("\n");
        transcript.append("ID: ").append(getId()).append("\n");
        transcript.append("Reg No: ").append(regNo).append("\n\n");
        transcript.append("Course Grades:\n");
        
        if (courseGrades.isEmpty()) {
            transcript.append("No grades recorded.\n");
        } else {
            courseGrades.entrySet().stream()
                    .sorted(Map.Entry.comparingByKey())
                    .forEach(entry -> 
                        transcript.append(entry.getKey()).append(": ")
                                 .append(entry.getValue()).append("\n"));
        }
        
        transcript.append("\nOverall GPA: ").append(String.format("%.2f", calculateGPA()));
        transcript.append("\nTotal Credits: ").append(getTotalCredits());
        transcript.append("\n==================\n");
        
        return transcript.toString();
    }
    
    @Override
    public String toString() {
        return "Student{id='" + getId() + "', regNo='" + regNo + "', name=" + getName() +
               ", status=" + status + ", courses=" + enrolledCourses.size() +
               ", gpa=" + String.format("%.2f", calculateGPA()) + "}";
    }
}

// Course class with Builder pattern
class Course {
    private final String code;
    private final String title;
    private final int credits;
    private String instructorId;
    private Semester semester;
    private String department;
    private int maxEnrollment;
    private int currentEnrollment;
    private boolean isActive;
    
    private Course(Builder builder) {
        this.code = builder.code;
        this.title = builder.title;
        this.credits = builder.credits;
        this.instructorId = builder.instructorId;
        this.semester = builder.semester;
        this.department = builder.department;
        this.maxEnrollment = builder.maxEnrollment;
        this.currentEnrollment = 0;
        this.isActive = true;
    }
    
    // Builder nested class
    public static class Builder {
        private final String code;
        private final String title;
        private final int credits;
        
        private String instructorId = "";
        private Semester semester = Semester.FALL;
        private String department = "";
        private int maxEnrollment = 50;
        
        public Builder(String code, String title, int credits) {
            this.code = Objects.requireNonNull(code);
            this.title = Objects.requireNonNull(title);
            this.credits = credits;
        }
        
        public Builder instructorId(String instructorId) {
            this.instructorId = instructorId != null ? instructorId : "";
            return this;
        }
        
        public Builder semester(Semester semester) {
            this.semester = semester != null ? semester : Semester.FALL;
            return this;
        }
        
        public Builder department(String department) {
            this.department = department != null ? department : "";
            return this;
        }
        
        public Builder maxEnrollment(int maxEnrollment) {
            this.maxEnrollment = maxEnrollment;
            return this;
        }
        
        public Course build() {
            return new Course(this);
        }
    }
    
    // Getters and setters
    public String getCode() { return code; }
    public String getTitle() { return title; }
    public int getCredits() { return credits; }
    public String getInstructorId() { return instructorId; }
    public void setInstructorId(String instructorId) { this.instructorId = instructorId; }
    public Semester getSemester() { return semester; }
    public void setSemester(Semester semester) { this.semester = semester; }
    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }
    public int getMaxEnrollment() { return maxEnrollment; }
    public int getCurrentEnrollment() { return currentEnrollment; }
    public void setCurrentEnrollment(int currentEnrollment) { this.currentEnrollment = currentEnrollment; }
    public boolean isActive() { return isActive; }
    public void setActive(boolean active) { this.isActive = active; }
    
    public boolean canEnrollStudent() {
        return isActive && currentEnrollment < maxEnrollment;
    }
    
    public boolean enrollStudent() {
        if (canEnrollStudent()) {
            currentEnrollment++;
            return true;
        }
        return false;
    }
    
    public double getEnrollmentPercentage() {
        return maxEnrollment == 0 ? 0.0 : (double) currentEnrollment / maxEnrollment * 100;
    }
    
    @Override
    public String toString() {
        return "Course{code='" + code + "', title='" + title + "', credits=" + credits +
               ", instructor='" + instructorId + "', semester=" + semester +
               ", dept='" + department + "', enrollment=" + currentEnrollment + "/" + maxEnrollment +
               ", active=" + isActive + "}";
    }
}

// Custom Exceptions
class DuplicateEnrollmentException extends Exception {
    private final String studentId;
    private final String courseCode;
    
    public DuplicateEnrollmentException(String studentId, String courseCode) {
        super("Student " + studentId + " is already enrolled in course " + courseCode);
        this.studentId = studentId;
        this.courseCode = courseCode;
    }
    
    public String getStudentId() { return studentId; }
    public String getCourseCode() { return courseCode; }
}

class MaxCreditLimitExceededException extends RuntimeException {
    private final String studentId;
    private final int currentCredits;
    private final int maxCredits;
    
    public MaxCreditLimitExceededException(String studentId, int currentCredits, int maxCredits) {
        super("Student " + studentId + " cannot exceed " + maxCredits + 
              " credits (currently has " + currentCredits + ")");
        this.studentId = studentId;
        this.currentCredits = currentCredits;
        this.maxCredits = maxCredits;
    }
    
    public String getStudentId() { return studentId; }
    public int getCurrentCredits() { return currentCredits; }
    public int getMaxCredits() { return maxCredits; }
}

// Student Service class
class StudentService {
    private final Map<String, Student> students;
    private final AppConfig config;
    
    public StudentService() {
        this.students = new HashMap<>();
        this.config = AppConfig.getInstance();
        loadSampleData();
    }
    
    public void save(Student student) {
        students.put(student.getId(), student);
    }
    
    public Student findById(String id) {
        return students.get(id);
    }
    
    public List<Student> findAll() {
        return new ArrayList<>(students.values());
    }
    
    public List<Student> findActiveStudents() {
        return students.values().stream()
                .filter(s -> s.getStatus() == Student.StudentStatus.ACTIVE)
                .collect(Collectors.toList());
    }
    
    public List<Student> searchByKeyword(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return findAll();
        }
        
        String lowerKeyword = keyword.toLowerCase();
        return students.values().stream()
                .filter(student -> 
                    student.getName().getFullName().toLowerCase().contains(lowerKeyword) ||
                    student.getEmail().toLowerCase().contains(lowerKeyword) ||
                    student.getRegNo().toLowerCase().contains(lowerKeyword))
                .collect(Collectors.toList());
    }
    
    public void enrollStudentInCourse(String studentId, String courseCode) 
            throws DuplicateEnrollmentException, MaxCreditLimitExceededException {
        
        Student student = findById(studentId);
        if (student == null) {
            throw new IllegalArgumentException("Student not found: " + studentId);
        }
        
        if (student.isEnrolledIn(courseCode)) {
            throw new DuplicateEnrollmentException(studentId, courseCode);
        }
        
        int currentCredits = student.getTotalCredits();
        int maxCredits = config.getMaxCreditsPerSemester();
        
        if (currentCredits + 3 > maxCredits) {
            throw new MaxCreditLimitExceededException(studentId, currentCredits, maxCredits);
        }
        
        student.enrollInCourse(courseCode);
        System.out.println("Student " + studentId + " enrolled in course " + courseCode);
    }
    
    public void recordGrade(String studentId, String courseCode, Grade grade) {
        Student student = findById(studentId);
        if (student != null && student.isEnrolledIn(courseCode)) {
            student.recordGrade(courseCode, grade);
            System.out.println("Grade " + grade + " recorded for student " + studentId + 
                              " in course " + courseCode);
        }
    }
    
    public Map<String, Object> generateStatistics() {
        List<Student> allStudents = findAll();
        Map<String, Object> stats = new HashMap<>();
        
        stats.put("totalStudents", allStudents.size());
        stats.put("activeStudents", findActiveStudents().size());
        
        double avgGPA = allStudents.stream()
                .mapToDouble(Student::calculateGPA)
                .average()
                .orElse(0.0);
        stats.put("averageGPA", avgGPA);
        
        return stats;
    }
    
    private void loadSampleData() {
        // Load some sample students
        Student student1 = new Student("STU001", "2024001", 
                new Name("John", "Doe"), "john.doe@university.edu", 
                LocalDate.of(2000, 5, 15));
        student1.enrollInCourse("CS101");
        student1.enrollInCourse("MATH201");
        student1.recordGrade("CS101", Grade.A);
        
        Student student2 = new Student("STU002", "2024002",
                new Name("Jane", "Smith"), "jane.smith@university.edu",
                LocalDate.of(1999, 8, 22));
        student2.enrollInCourse("CS101");
        student2.recordGrade("CS101", Grade.B);
        
        save(student1);
        save(student2);
    }
}

// Course Service class  
class CourseService {
    private final Map<String, Course> courses;
    
    public CourseService() {
        this.courses = new HashMap<>();
        loadSampleData();
    }
    
    public void save(Course course) {
        courses.put(course.getCode(), course);
    }
    
    public Course findById(String code) {
        return code != null ? courses.get(code.toUpperCase()) : null;
    }
    
    public List<Course> findAll() {
        return new ArrayList<>(courses.values());
    }
    
    public List<Course> findActiveCourses() {
        return courses.values().stream()
                .filter(Course::isActive)
                .collect(Collectors.toList());
    }
    
    public List<Course> sortByCode() {
        return courses.values().stream()
                .sorted(Comparator.comparing(Course::getCode))
                .collect(Collectors.toList());
    }
    
    private void loadSampleData() {
        Course cs101 = new Course.Builder("CS101", "Introduction to Computer Science", 3)
                .department("Computer Science")
                .semester(Semester.FALL)
                .maxEnrollment(40)
                .build();
        cs101.setCurrentEnrollment(25);
        
        Course math201 = new Course.Builder("MATH201", "Calculus II", 4)
                .department("Mathematics")
                .semester(Semester.SPRING)
                .maxEnrollment(35)
                .build();
        
        save(cs101);
        save(math201);
    }
}

// Command Line Interface
class CCRMCommandLine {
    private final Scanner scanner;
    private final StudentService studentService;
    private final CourseService courseService;
    private final AppConfig config;
    private boolean running;
    
    public CCRMCommandLine() {
        this.scanner = new Scanner(System.in);
        this.studentService = new StudentService();
        this.courseService = new CourseService();
        this.config = AppConfig.getInstance();
        this.running = true;
    }
    
    public void run() {
        config.displayPlatformInfo();
        System.out.println("Welcome to Campus Course & Records Manager (CCRM)");
        System.out.println("Startup time: " + config.getStartupTime());
        
        while (running) {
            try {
                displayMainMenu();
                int choice = getIntegerInput("Enter your choice: ");
                
                switch (choice) {
                    case 1 -> handleStudentManagement();
                    case 2 -> handleCourseManagement();
                    case 3 -> handleEnrollmentManagement();
                    case 4 -> handleGradeManagement();
                    case 5 -> handleReports();
                    case 6 -> demonstrateFeatures();
                    case 7 -> {
                        System.out.println("Thank you for using CCRM!");
                        running = false;
                    }
                    default -> System.out.println("Invalid choice. Please try again.");
                }
            } catch (Exception e) {
                System.err.println("An error occurred: " + e.getMessage());
                scanner.nextLine(); // Clear invalid input
            }
        }
        
        scanner.close();
    }
    
    private void displayMainMenu() {
        System.out.println("\n" + "=".repeat(50));
        System.out.println("         CCRM - MAIN MENU");
        System.out.println("=".repeat(50));
        System.out.println("1. Student Management");
        System.out.println("2. Course Management");
        System.out.println("3. Enrollment Management");
        System.out.println("4. Grade Management");
        System.out.println("5. Reports & Statistics");
        System.out.println("6. Java Features Demo");
        System.out.println("7. Exit");
        System.out.println("=".repeat(50));
    }
    
    private void handleStudentManagement() {
        while (true) {
            System.out.println("\n--- Student Management ---");
            System.out.println("1. Add Student");
            System.out.println("2. List All Students");
            System.out.println("3. Search Students");
            System.out.println("4. Display Student Profile");
            System.out.println("0. Back to Main Menu");
            
            int choice = getIntegerInput("Enter choice: ");
            
            switch (choice) {
                case 1 -> addNewStudent();
                case 2 -> listAllStudents();
                case 3 -> searchStudents();
                case 4 -> displayStudentProfile();
                case 0 -> { return; }
                default -> System.out.println("Invalid choice!");
            }
        }
    }
    
    private void handleCourseManagement() {
        while (true) {
            System.out.println("\n--- Course Management ---");
            System.out.println("1. Add Course");
            System.out.println("2. List All Courses");
            System.out.println("0. Back to Main Menu");
            
            int choice = getIntegerInput("Enter choice: ");
            
            switch (choice) {
                case 1 -> addNewCourse();
                case 2 -> listAllCourses();
                case 0 -> { return; }
                default -> System.out.println("Invalid choice!");
            }
        }
    }
    
    private void handleEnrollmentManagement() {
        while (true) {
            System.out.println("\n--- Enrollment Management ---");
            System.out.println("1. Enroll Student in Course");
            System.out.println("2. View Student Enrollments");
            System.out.println("0. Back");
            
            int choice = getIntegerInput("Enter choice: ");
            
            switch (choice) {
                case 1 -> enrollStudentInCourse();
                case 2 -> viewStudentEnrollments();
                case 0 -> { return; }
                default -> System.out.println("Invalid choice!");
            }
        }
    }
    
    private void handleGradeManagement() {
        while (true) {
            System.out.println("\n--- Grade Management ---");
            System.out.println("1. Record Grade");
            System.out.println("2. View Student Grades");
            System.out.println("3. Generate Transcript");
            System.out.println("0. Back");
            
            int choice = getIntegerInput("Enter choice: ");
            
            switch (choice) {
                case 1 -> recordGrade();
                case 2 -> viewStudentGrades();
                case 3 -> generateTranscript();
                case 0 -> { return; }
                default -> System.out.println("Invalid choice!");
            }
        }
    }
    
    private void handleReports() {
        System.out.println("\n--- Reports & Statistics ---");
        Map<String, Object> stats = studentService.generateStatistics();
        System.out.println("Student Statistics:");
        stats.forEach((key, value) -> System.out.println(key + ": " + value));
    }
    
    private void demonstrateFeatures() {
        System.out.println("\n--- Java Features Demo ---");
        System.out.println("1. Lambda Expressions");
        System.out.println("2. Stream API");
        System.out.println("3. Polymorphism");
        System.out.println("4. Design Patterns");
        System.out.println("0. Back");
        
        int choice = getIntegerInput("Enter choice: ");
        
        switch (choice) {
            case 1 -> demonstrateLambdas();
            case 2 -> demonstrateStreams();
            case 3 -> demonstratePolymorphism();
            case 4 -> demonstrateDesignPatterns();
            case 0 -> { return; }
            default -> System.out.println("Invalid choice!");
        }
    }
    
    // Implementation methods
    private void addNewStudent() {
        try {
            System.out.println("\n--- Add New Student ---");
            String id = getStringInput("Enter Student ID (STU###): ");
            String regNo = getStringInput("Enter Registration Number: ");
            String firstName = getStringInput("Enter First Name: ");
            String lastName = getStringInput("Enter Last Name: ");
            String email = getStringInput("Enter Email: ");
            
            Name name = new Name(firstName, lastName);
            LocalDate dob = LocalDate.of(2000, 1, 1); // Simplified for demo
            
            Student student = new Student(id, regNo, name, email, dob);
            studentService.save(student);
            
            System.out.println("Student added successfully!");
        } catch (Exception e) {
            System.err.println("Error adding student: " + e.getMessage());
        }
    }
    
    private void listAllStudents() {
        System.out.println("\n--- All Students ---");
        List<Student> students = studentService.findAll();
        
        if (students.isEmpty()) {
            System.out.println("No students found.");
            return;
        }
        
        students.forEach(System.out::println);
        System.out.println("\nTotal students: " + students.size());
    }
    
    private void searchStudents() {
        System.out.println("\n--- Search Students ---");
        String keyword = getStringInput("Enter search keyword: ");
        
        List<Student> results = studentService.searchByKeyword(keyword);
        
        if (results.isEmpty()) {
            System.out.println("No students found matching: " + keyword);
        } else {
            System.out.println("Found " + results.size() + " students:");
            results.forEach(System.out::println);
        }
    }
    
    private void displayStudentProfile() {
        String studentId = getStringInput("Enter Student ID: ");
        Student student = studentService.findById(studentId);
        if (student != null) {
            student.displayProfile();
        } else {
            System.out.println("Student not found!");
        }
    }
    
    private void addNewCourse() {
        try {
            System.out.println("\n--- Add New Course ---");
            String code = getStringInput("Enter Course Code (e.g., CS101): ");
            String title = getStringInput("Enter Course Title: ");
            int credits = getIntegerInput("Enter Credits: ");
            String department = getStringInput("Enter Department: ");
            
            Course course = new Course.Builder(code, title, credits)
                    .department(department)
                    .semester(Semester.FALL)
                    .maxEnrollment(30)
                    .build();
            
            courseService.save(course);
            System.out.println("Course added successfully!");
        } catch (Exception e) {
            System.err.println("Error adding course: " + e.getMessage());
        }
    }
    
    private void listAllCourses() {
        System.out.println("\n--- All Courses ---");
        List<Course> courses = courseService.sortByCode();
        
        if (courses.isEmpty()) {
            System.out.println("No courses found.");
            return;
        }
        
        courses.forEach(System.out::println);
        System.out.println("\nTotal courses: " + courses.size());
    }
    
    private void enrollStudentInCourse() {
        try {
            String studentId = getStringInput("Enter Student ID: ");
            String courseCode = getStringInput("Enter Course Code: ");
            
            studentService.enrollStudentInCourse(studentId, courseCode);
        } catch (DuplicateEnrollmentException e) {
            System.err.println("Enrollment Error: " + e.getMessage());
        } catch (MaxCreditLimitExceededException e) {
            System.err.println("Credit Limit Error: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Unexpected error: " + e.getMessage());
        }
    }
    
    private void viewStudentEnrollments() {
        String studentId = getStringInput("Enter Student ID: ");
        Student student = studentService.findById(studentId);
        if (student != null) {
            System.out.println("Enrolled Courses for " + student.getName().getFullName() + ":");
            student.getEnrolledCourses().forEach(courseCode -> 
                System.out.println("- " + courseCode));
        } else {
            System.out.println("Student not found!");
        }
    }
    
    private void recordGrade() {
        try {
            String studentId = getStringInput("Enter Student ID: ");
            String courseCode = getStringInput("Enter Course Code: ");
            
            System.out.println("Available Grades:");
            System.out.println("1. S (10.0)  2. A (9.0)  3. B (8.0)  4. C (7.0)");
            System.out.println("5. D (6.0)   6. E (5.0)  7. F (0.0)");
            
            int gradeChoice = getIntegerInput("Select grade (1-7): ");
            Grade grade = switch (gradeChoice) {
                case 1 -> Grade.S;
                case 2 -> Grade.A;
                case 3 -> Grade.B;
                case 4 -> Grade.C;
                case 5 -> Grade.D;
                case 6 -> Grade.E;
                case 7 -> Grade.F;
                default -> null;
            };
            
            if (grade != null) {
                studentService.recordGrade(studentId, courseCode, grade);
                System.out.println("Grade recorded successfully!");
            } else {
                System.out.println("Invalid grade choice!");
            }
        } catch (Exception e) {
            System.err.println("Error recording grade: " + e.getMessage());
        }
    }
    
    private void viewStudentGrades() {
        String studentId = getStringInput("Enter Student ID: ");
        Student student = studentService.findById(studentId);
        if (student != null) {
            Map<String, Grade> grades = student.getAllGrades();
            if (grades.isEmpty()) {
                System.out.println("No grades recorded for this student.");
            } else {
                System.out.println("Grades for " + student.getName().getFullName() + ":");
                grades.forEach((courseCode, grade) -> 
                    System.out.println("- " + courseCode + ": " + grade));
                System.out.println("Overall GPA: " + String.format("%.2f", student.calculateGPA()));
            }
        } else {
            System.out.println("Student not found!");
        }
    }
    
    private void generateTranscript() {
        String studentId = getStringInput("Enter Student ID: ");
        Student student = studentService.findById(studentId);
        
        if (student != null) {
            System.out.println(student.generateTranscript());
        } else {
            System.out.println("Student not found!");
        }
    }
    
    private void demonstrateLambdas() {
        System.out.println("\n--- Lambda Expressions Demo ---");
        
        List<Student> students = studentService.findAll();
        
        // Lambda with Predicate
        Predicate<Student> highGPA = student -> student.calculateGPA() > 8.0;
        List<Student> topStudents = students.stream()
                .filter(highGPA)
                .collect(Collectors.toList());
        System.out.println("Students with GPA > 8.0: " + topStudents.size());
        
        // Lambda with Consumer
        System.out.println("Student names:");
        students.forEach(s -> System.out.println("- " + s.getName().getFullName()));
    }
    
    private void demonstrateStreams() {
        System.out.println("\n--- Stream API Demo ---");
        
        List<Student> students = studentService.findAll();
        
        // Complex stream pipeline
        double avgGPA = students.stream()
                .filter(s -> s.getStatus() == Student.StudentStatus.ACTIVE)
                .mapToDouble(Student::calculateGPA)
                .filter(gpa -> gpa > 0)
                .average()
                .orElse(0.0);
        
        System.out.println("Average GPA of active students: " + String.format("%.2f", avgGPA));
        
        // Group by status
        Map<Student.StudentStatus, List<Student>> studentsByStatus = students.stream()
                .collect(Collectors.groupingBy(Student::getStatus));
        
        System.out.println("\nStudents by status:");
        studentsByStatus.forEach((status, list) -> 
                System.out.println(status + ": " + list.size()));
    }
    
    private void demonstratePolymorphism() {
        System.out.println("\n--- Polymorphism Demo ---");
        
        List<Student> students = studentService.findAll();
        if (!students.isEmpty()) {
            Person person = students.get(0); // Upcast
            
            System.out.println("Person Type: " + person.getPersonType());
            person.displayProfile(); // Virtual method invocation
            
            // Runtime type checking and casting
            if (person instanceof Student) {
                Student student = (Student) person; // Downcast
                System.out.println("Student GPA: " + student.calculateGPA());
            }
        }
    }
    
    private void demonstrateDesignPatterns() {
        System.out.println("\n--- Design Patterns Demo ---");
        
        // Singleton pattern
        AppConfig config1 = AppConfig.getInstance();
        AppConfig config2 = AppConfig.getInstance();
        System.out.println("Singleton test - Same instance: " + (config1 == config2));
        
        // Builder pattern
        Course course = new Course.Builder("DEMO101", "Demo Course", 3)
                .department("Demo Department")
                .semester(Semester.SPRING)
                .maxEnrollment(25)
                .build();
        
        System.out.println("Builder pattern - Created course: " + course);
    }
    
    // Helper methods
    private String getStringInput(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine().trim();
    }
    
    private int getIntegerInput(String prompt) {
        while (true) {
            try {
                System.out.print(prompt);
                int value = Integer.parseInt(scanner.nextLine().trim());
                return value;
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }
}